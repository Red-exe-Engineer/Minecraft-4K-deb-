Controls are buggy

Packaged by Wallee

Credit:
Notch, for Minecraft 4K in the first place
The MCPI-Revival team, providing the jar
Botspot, for stating that you need a .desktop after the launcher name
